/*
  ex2-segmentation
  ================

  This example shows a minimal image segmentation code based on GridCut.
*/

#include <cstdio>
#include <cmath>
#include <GridCut/GridGraph_2D_4C.h>

#define FG 255
#define BG 128

#define K 1024
#define SIGMA2 16.0f

#define WEIGHT(A) (int)(1+K*expf((-(A)*(A)/SIGMA2)))

unsigned char *load_TGA(const char *name, unsigned short &w, unsigned short &h);
void save_TGA(const char *name, unsigned char *buf, unsigned short w, unsigned short h);

int main(int argc, char **argv)
{
  typedef GridGraph_2D_4C<short,short,short> Grid;

  unsigned short x,y,w,h,cap;
  unsigned char *img,*msk;
  
  img = load_TGA("image.tga",w,h);
  msk = load_TGA("mask.tga",w,h);
  
  #define IMG(X,Y) img[(X)+(Y)*w]
  #define MSK(X,Y) msk[(X)+(Y)*w]

  Grid* grid = new Grid(w,h);
  
  for (y=0;y<h;y++)
  {
    for (x=0;x<w;x++)
    {
      grid->set_terminal_cap(grid->node_id(x,y),(MSK(x,y)==FG)*K,(MSK(x,y)==BG)*K);

      if (x<w-1)
      {
        cap = WEIGHT(IMG(x,y)-IMG(x+1,y));

        grid->set_neighbor_cap(grid->node_id(x,y),  +1,0,cap);
        grid->set_neighbor_cap(grid->node_id(x+1,y),-1,0,cap);
      }

      if (y<h-1)
      {
        cap = WEIGHT(IMG(x,y)-IMG(x,y+1));

        grid->set_neighbor_cap(grid->node_id(x,y),  0,+1,cap);
        grid->set_neighbor_cap(grid->node_id(x,y+1),0,-1,cap);
      }
    }
  }

  grid->compute_maxflow();

  for (y=0;y<h;y++)
  {
    for (x=0;x<w;x++)
    {
      if (grid->get_segment(grid->node_id(x,y))) IMG(x,y)=0;
    }
  }

  save_TGA("output.tga",img,w,h);

  delete grid;

  return 0;
}

unsigned char *load_TGA(const char *name, unsigned short &w, unsigned short &h)
{
 unsigned char *buf;

 FILE *f=fopen(name,"rb");

 if (!f) return 0;

 fseek(f,12,SEEK_SET);
 fread(&w,1,sizeof(w),f);
 fread(&h,1,sizeof(h),f);

 buf=new unsigned char[w*h];

 fseek(f,786,SEEK_SET);
 fread(buf,1,w*h,f);

 fclose(f);

 return buf;
}

unsigned char TGA_head[]={0,1,1,0,0,0,1,24,0,0,0,0};

void save_TGA(const char *name, unsigned char *buf, unsigned short w, unsigned short h)
{
 unsigned short b=8; unsigned char pal[3*256];

 for (int i=0;i<3*256;i++) pal[i]=i/3;

 FILE *f=fopen(name,"wb");

 fwrite(TGA_head,1,sizeof(TGA_head),f);
 fwrite(&w,1,sizeof(w),f);
 fwrite(&h,1,sizeof(h),f);
 fwrite(&b,1,sizeof(h),f);
 fwrite(pal,1,256*3,f);
 fwrite(buf,1,w*h,f);

 fclose(f);
}
